# CustomerSettings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**updateRefundDetails** | **Boolean** | Update refund details |  [optional]
**updateChargeDetails** | **Boolean** | Update charge details |  [optional]
**allowPublicationsByMail** | **Boolean** | Allow publications by mail |  [optional]
**allowPublicationsBySMS** | **Boolean** | Allow publications by sms |  [optional]
