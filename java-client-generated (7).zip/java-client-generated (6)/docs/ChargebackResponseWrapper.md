# ChargebackResponseWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**chargebackUpdateResponseList** | [**List&lt;UpdateChargebackDataResponse&gt;**](UpdateChargebackDataResponse.md) |  |  [optional]
