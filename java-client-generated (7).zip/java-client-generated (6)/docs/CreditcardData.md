# CreditcardData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ccTokens** | **List&lt;String&gt;** | List of creditcard tokens |  [optional]
