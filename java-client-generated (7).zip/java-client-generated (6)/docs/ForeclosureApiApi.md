# ForeclosureApiApi

All URIs are relative to *https://lfapi-test.pais.corp*

Method | HTTP request | Description
------------- | ------------- | -------------
[**updateForeclosure**](ForeclosureApiApi.md#updateForeclosure) | **POST** /api/customer/foreclosure | Endpoint to handle foreclosure requests. Matches BPM206

<a name="updateForeclosure"></a>
# **updateForeclosure**
> ForeclosureResponseDto updateForeclosure(body, uuid)

Endpoint to handle foreclosure requests. Matches BPM206

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.ForeclosureApiApi;


ForeclosureApiApi apiInstance = new ForeclosureApiApi();
ForeclosureRequestDto body = new ForeclosureRequestDto(); // ForeclosureRequestDto | 
String uuid = "uuid_example"; // String | 
try {
    ForeclosureResponseDto result = apiInstance.updateForeclosure(body, uuid);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling ForeclosureApiApi#updateForeclosure");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**ForeclosureRequestDto**](ForeclosureRequestDto.md)|  |
 **uuid** | **String**|  |

### Return type

[**ForeclosureResponseDto**](ForeclosureResponseDto.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

