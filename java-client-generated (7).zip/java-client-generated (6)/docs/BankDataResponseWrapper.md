# BankDataResponseWrapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bankDataResponseList** | [**List&lt;BankdataValidationRequestResponse&gt;**](BankdataValidationRequestResponse.md) |  |  [optional]
