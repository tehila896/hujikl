# BankAccountData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bankCode** | **String** | Bank code |  [optional]
**branchCode** | **String** | Branch code |  [optional]
**accountNumber** | **String** | Account number |  [optional]
