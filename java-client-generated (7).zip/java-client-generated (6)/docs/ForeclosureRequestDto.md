# ForeclosureRequestDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nationalId** | **String** |  |  [optional]
**foreclosureStatus** | [**ForeclosureStatusEnum**](#ForeclosureStatusEnum) |  |  [optional]

<a name="ForeclosureStatusEnum"></a>
## Enum: ForeclosureStatusEnum
Name | Value
---- | -----
FORECLOSURE_ACTIVE | &quot;FORECLOSURE_ACTIVE&quot;
FORECLOSURE_ENDED | &quot;FORECLOSURE_ENDED&quot;
DO_NOTHING | &quot;DO_NOTHING&quot;
